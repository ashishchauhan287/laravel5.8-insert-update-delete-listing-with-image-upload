<!-- index.blade.php -->

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  </head>
  <body>
    <div class="container">
    <br />
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?>
     <div class="row">
     <div class="col-lg-8">
     <h1>Coin List</h1>
     </div>
     <div class="col-lg-4">
     <a href="<?php echo e(action('FormController@create')); ?>" class="btn btn-primary">Add New Coin</a>
     </div>
     </div>
    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>CoinName</th>
        <th>CoinPrice</th>
        <th>CoinImage</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($form['id']); ?></td>
        <td><?php echo e($form['coinname']); ?></td>
        <td><?php echo e($form['coinprice']); ?></td>
        <?php if($form['coinimage'] != ''): ?>
        <td><img style="width:50px;" src="<?php echo e(asset('images/'.$form['coinimage'])); ?>" alt="coinimages"/></td>
        <?php else: ?>
        <td><img style="width:50px;" src="<?php echo e(asset('images/images.png')); ?>" alt="coinimages"/></td>
        <?php endif; ?>
        <td><a href="<?php echo e(action('FormController@edit', $form['id'])); ?>" class="btn btn-warning">Edit</a></td>
        <td>
          <form action="<?php echo e(action('FormController@destroy', $form['id'])); ?>" method="post" onsubmit="return confirm('Do you really want to Delete?');">
            <?php echo e(csrf_field()); ?>

            <input name="_method" type="hidden" value="DELETE">
            <input name="coinimage" type="hidden" value="<?php echo e($form['coinimage']); ?>">
            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
  </body>
</html>

