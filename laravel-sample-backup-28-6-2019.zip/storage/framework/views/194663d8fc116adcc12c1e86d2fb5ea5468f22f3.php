<!-- edit.blade.php -->
<?php 
    $values = explode(",", $form->checkbox);
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Laravel 5 CRUD Tutorial With Example From Scratch </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  </head>
  <body>
    <div class="container">
    <br />
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div><br />
      <?php endif; ?>
      <div class="row">
     <div class="col-lg-8">
     <h2>Edit Coin</h2>
     </div>
     <div class="col-lg-4">
     <a href="<?php echo e(action('FormController@index')); ?>" class="btn btn-primary">View Coin List</a>
     </div>
     </div>
      <form method="post" action="<?php echo e(action('FormController@update', $id)); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input name="_method" type="hidden" value="PATCH">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="name">CoinName:</label>
            <input type="text" class="form-control" name="coinname" value="<?php echo e($form->coinname); ?>">
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="price">CoinPrice:</label>
              <input type="text" class="form-control" name="coinprice" value="<?php echo e($form->coinprice); ?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4" style="margin-left:38px">

                 <lable>Keep</lable>
                   <input type="radio" name="radio" value="keep"  <?php if($form->radio == 'keep'): ?> checked <?php endif; ?>>
                 <lable>Port</lable>
                     <input type="radio" name="radio" value="port"  <?php if($form->radio == 'port'): ?> checked <?php endif; ?>>
            </div>
        </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4" style="margin-left:38px">
                <lable>Level</lable>
                <select name="dropdown">
                  <option value="beginner"  <?php if($form->dropdown=="beginner"): ?> selected <?php endif; ?>>Beginner</option>
                  <option value="intermediate"  <?php if($form->dropdown=="intermediate"): ?> selected <?php endif; ?>>Intermediate</option>
                  <option value="advance" <?php if($form->dropdown=="advance"): ?> selected <?php endif; ?>>Advance</option>  
                </select>
            </div>
        </div>
         <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4" style="margin-left:38px">

               <lable>Exchanges :</lable>
               <div class="checkbox">
                  <label><input type="checkbox" value="coindesk" name="option[]" <?php if(in_array("coindesk", $values)): ?> checked <?php endif; ?>>Coindesk</label>
               </div>
                <div class="checkbox">
                   <label><input type="checkbox" value="coinbase" name="option[]"  <?php if(in_array("coinbase", $values)): ?> checked <?php endif; ?>>CoinBase</label>
              </div>
               <div class="checkbox">
                  <label><input type="checkbox" value="zebpay" name="option[]" <?php if(in_array("zebpay", $values)): ?> checked <?php endif; ?>>Zebpay</label>
               </div>
            </div>
        </div>

        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4" style="margin-left:38px">

               <lable>Coin Image :</lable>
               <input type="file" name="coinimage" id="coinimage" >
               <input type="hidden" name="oldimage" id="oldimage" value="<?php echo e($form->coinimage); ?>">
               <?php if($form->coinimage==""): ?>
               <img style="width:50px;padding-left:10px;" src="<?php echo e(asset('images/images.png')); ?>" alt="coinimages"/>
                <?php else: ?>
                <img style="width:50px;padding-left:10px;" src="<?php echo e(asset('images/'.$form->coinimage)); ?>" alt="coinimages"/>
                <?php endif; ?>
            </div>
         </div>
        </div>

        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <button type="submit" class="btn btn-success" style="margin-left:38px">Update</button>
          </div>
        </div>
      </form>
    </div>
  </body>
</html>